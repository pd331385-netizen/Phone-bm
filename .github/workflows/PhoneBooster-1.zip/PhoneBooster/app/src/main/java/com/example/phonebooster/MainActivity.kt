package com.example.phonebooster

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.os.StatFs
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var tvRam: TextView
    private lateinit var pbRam: ProgressBar
    private lateinit var tvStorage: TextView
    private lateinit var pbStorage: ProgressBar
    private lateinit var tvBattery: TextView
    private lateinit var tvThermal: TextView
    private lateinit var tvResult: TextView
    private lateinit var llApps: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvRam = findViewById(R.id.tvRam)
        pbRam = findViewById(R.id.pbRam)
        tvStorage = findViewById(R.id.tvStorage)
        pbStorage = findViewById(R.id.pbStorage)
        tvBattery = findViewById(R.id.tvBattery)
        tvThermal = findViewById(R.id.tvThermal)
        tvResult = findViewById(R.id.tvResult)
        llApps = findViewById(R.id.llApps)

        findViewById<Button>(R.id.btnBoost).setOnClickListener { boost() }
        findViewById<Button>(R.id.btnCool).setOnClickListener { coolMode() }
        findViewById<Button>(R.id.btnService).setOnClickListener { toggleService() }
        findViewById<Button>(R.id.btnUsage).setOnClickListener { scanApps() }
        findViewById<Button>(R.id.btnStorage).setOnClickListener {
            open(Settings.ACTION_INTERNAL_STORAGE_SETTINGS, Settings.ACTION_MEMORY_CARD_SETTINGS)
        }
        findViewById<Button>(R.id.btnApps).setOnClickListener {
            open(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS, Settings.ACTION_APPLICATION_SETTINGS)
        }
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            open(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, Settings.ACTION_BATTERY_SAVER_SETTINGS)
        }
        findViewById<Button>(R.id.btnDev).setOnClickListener {
            open(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, Settings.ACTION_DEVICE_INFO_SETTINGS)
            Toast.makeText(
                this,
                "Developer options बंद हो तो About phone में Build number 7 बार दबाओ",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStats()
        updateServiceButton()
    }

    private fun refreshStats() {
        // RAM
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val usedRam = mi.totalMem - mi.availMem
        val ramPct = (usedRam * 100 / mi.totalMem).toInt()
        tvRam.text = "RAM: ${fmt(usedRam)} / ${fmt(mi.totalMem)} इस्तेमाल ($ramPct%)"
        pbRam.progress = ramPct

        // Storage
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.totalBytes
        val free = st.availableBytes
        val usedPct = ((total - free) * 100 / total).toInt()
        tvStorage.text = "स्टोरेज: ${fmt(free)} खाली / ${fmt(total)}" +
            if (usedPct > 85) "  ⚠️ बहुत भरा है, यही लैग की बड़ी वजह है" else ""
        pbStorage.progress = usedPct

        // Battery temperature
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        tvBattery.text = "तापमान: $temp°C  |  बैटरी: $level%" +
            if (temp >= 40f) "\n🔥 फ़ोन गर्म है: कूल मोड दबाओ" else ""

        // Thermal status (Android 10+)
        tvThermal.text = if (Build.VERSION.SDK_INT >= 29) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val s = when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "✅ ठीक है"
                PowerManager.THERMAL_STATUS_LIGHT -> "🙂 हल्की गर्मी"
                PowerManager.THERMAL_STATUS_MODERATE -> "😓 मध्यम गर्मी (परफ़ॉर्मेंस घट सकती है)"
                PowerManager.THERMAL_STATUS_SEVERE -> "🔥 बहुत गर्म (फ़ोन ख़ुद धीमा हो रहा है)"
                else -> "🚨 ख़तरनाक गर्मी, फ़ोन तुरंत आराम दो"
            }
            "थर्मल स्थिति: $s"
        } else {
            "थर्मल स्थिति: इस Android वर्ज़न पर उपलब्ध नहीं"
        }
    }

    // ---- 24 घंटे निगरानी ----

    private fun serviceOn() =
        getSharedPreferences("pb", MODE_PRIVATE).getBoolean("monitor", false)

    private fun updateServiceButton() {
        findViewById<Button>(R.id.btnService).text =
            if (serviceOn()) "🟢 24 घंटे निगरानी चालू (बंद करने को दबाओ)"
            else "⚪ 24 घंटे निगरानी चालू करो"
    }

    private fun toggleService() {
        val prefs = getSharedPreferences("pb", MODE_PRIVATE)
        if (serviceOn()) {
            stopService(Intent(this, CoolService::class.java))
            prefs.edit().putBoolean("monitor", false).apply()
        } else {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
                Toast.makeText(this, "नोटिफ़िकेशन की इजाज़त दो, फिर बटन दोबारा दबाओ", Toast.LENGTH_LONG).show()
                return
            }
            prefs.edit().putBoolean("monitor", true).apply()
            startForegroundService(Intent(this, CoolService::class.java))
            Toast.makeText(
                this,
                "चालू हो गया। \"बैटरी ऑप्टिमाइज़ेशन\" में इस ऐप को Unrestricted कर दो, वरना कंपनी का सिस्टम इसे बंद कर सकता है",
                Toast.LENGTH_LONG
            ).show()
        }
        updateServiceButton()
    }

    // ---- बूस्ट ----

    private fun killBackgroundApps(): Int {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var count = 0
        for (app in packageManager.getInstalledApplications(0)) {
            if (app.packageName == packageName) continue
            try {
                am.killBackgroundProcesses(app.packageName)
                count++
            } catch (_: Exception) {
            }
        }
        return count
    }

    private fun clearOwnCache(): Long {
        val freed = cacheDir.deepSize() + (externalCacheDir?.deepSize() ?: 0L)
        cacheDir.deleteChildren()
        externalCacheDir?.deleteChildren()
        return freed
    }

    private fun boost() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
        val killed = killBackgroundApps()
        val freed = clearOwnCache()

        tvResult.postDelayed({
            val after = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
            val gained = (after - before).coerceAtLeast(0)
            tvResult.text = "✅ $killed ऐप्स को बंद करने का अनुरोध भेजा\n" +
                "RAM खाली हुई: ${fmt(gained)}\n" +
                "कैश साफ़: ${fmt(freed)}\n\n" +
                "दूसरे ऐप्स का कैश साफ़ करने के लिए \"सारे ऐप्स\" वाला बटन दबाओ।"
            refreshStats()
        }, 800)
    }

    // ---- कूल मोड ----

    private fun coolMode() {
        val killed = killBackgroundApps()
        clearOwnCache()
        tvResult.text = "❄️ $killed बैकग्राउंड ऐप्स बंद करने का अनुरोध भेजा"
        refreshStats()

        AlertDialog.Builder(this)
            .setTitle("❄️ फ़ोन ठंडा करने के असली तरीके")
            .setMessage(
                "1. चार्जर निकाल दो (चार्जिंग सबसे ज़्यादा गर्मी देती है)\n" +
                    "2. कवर हटा दो\n" +
                    "3. गेम / कैमरा / वीडियो बंद करो\n" +
                    "4. धूप या गर्म जगह से हटाओ\n" +
                    "5. ब्राइटनेस कम करो, मोबाइल डेटा/GPS बंद करो\n" +
                    "6. Battery Saver चालू करो (अगला बटन)\n\n" +
                    "5-10 मिनट आराम दो, फ़ोन अपने आप ठंडा हो जाएगा।"
            )
            .setPositiveButton("Battery Saver खोलो") { _, _ ->
                open(Settings.ACTION_BATTERY_SAVER_SETTINGS, Settings.ACTION_SETTINGS)
            }
            .setNegativeButton("ठीक है", null)
            .show()
    }

    // ---- ऐप स्कैन ----

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun scanApps() {
        if (!hasUsageAccess()) {
            Toast.makeText(
                this,
                "लिस्ट में \"फ़ोन बूस्टर\" चुनकर Usage access चालू करो, फिर वापस आकर दोबारा स्कैन दबाओ",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }

        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val monthAgo = now - 30L * 24 * 3600 * 1000
        val stats = usm.queryAndAggregateUsageStats(monthAgo, now)

        val apps = packageManager.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != packageName }

        val top = apps
            .map { it to (stats[it.packageName]?.totalTimeInForeground ?: 0L) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(8)

        val unused = apps
            .filter { (stats[it.packageName]?.lastTimeUsed ?: 0L) < monthAgo }
            .take(12)

        llApps.removeAllViews()
        addHeader("📊 पिछले 30 दिन में सबसे ज़्यादा चले (टैप करो → Cache/Uninstall)")
        if (top.isEmpty()) addNote("अभी कोई डेटा नहीं मिला")
        top.forEach { (app, ms) ->
            addRow("${label(app)}  •  ${ms / 3600000} घंटे ${(ms / 60000) % 60} मिनट", app.packageName)
        }

        addHeader("🗑️ 30 दिन से इस्तेमाल नहीं किए (हटा दो, फ़ोन हल्का होगा)")
        if (unused.isEmpty()) addNote("कोई बेकार ऐप नहीं मिला 👍")
        unused.forEach { app -> addRow(label(app), app.packageName) }
    }

    private fun label(app: ApplicationInfo): String = packageManager.getApplicationLabel(app).toString()

    private fun addHeader(text: String) {
        llApps.addView(TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(0xFF1A237E.toInt())
            setPadding(0, 28, 0, 8)
        })
    }

    private fun addNote(text: String) {
        llApps.addView(TextView(this).apply {
            this.text = text
            setPadding(0, 8, 0, 8)
        })
    }

    private fun addRow(text: String, pkg: String) {
        llApps.addView(TextView(this).apply {
            this.text = "• $text"
            textSize = 15f
            setTextColor(0xFF212121.toInt())
            setPadding(0, 18, 0, 18)
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                )
            }
        })
    }

    // ---- हेल्पर ----

    private fun open(primary: String, fallback: String) {
        try {
            startActivity(Intent(primary))
        } catch (_: Exception) {
            try {
                startActivity(Intent(fallback))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
    }

    private fun fmt(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024) String.format("%.1f GB", mb / 1024) else String.format("%.0f MB", mb)
    }

    private fun java.io.File.deepSize(): Long =
        walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun java.io.File.deleteChildren() {
        listFiles()?.forEach { it.deleteRecursively() }
    }
}
