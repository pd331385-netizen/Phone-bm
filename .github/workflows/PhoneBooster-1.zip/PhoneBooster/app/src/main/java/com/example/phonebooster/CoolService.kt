package com.example.phonebooster

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock

/**
 * हल्की निगरानी: कोई टाइमर/लूप नहीं। सिर्फ़ तब जागता है जब सिस्टम बैटरी का तापमान बदलता है,
 * इसलिए CPU/बैटरी लगभग नहीं खाता। फ़ोन गर्म (HOT) होने पर ही बैकग्राउंड ऐप बंद करता है,
 * और 10 मिनट में एक बार से ज़्यादा नहीं (वरना ऐप बार-बार खुलकर लैग बढ़ाते)।
 */
class CoolService : Service() {

    private val hotTemp = 41f
    private val cooldownMs = 10 * 60_000L
    private val statusEveryMs = 60_000L

    private var lastStatus = -1L
    private var lastAction = -1L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val now = SystemClock.elapsedRealtime()

            if (lastStatus < 0 || now - lastStatus > statusEveryMs) {
                lastStatus = now
                updateStatus(temp, level)
            }

            if (temp >= hotTemp && (lastAction < 0 || now - lastAction > cooldownMs)) {
                lastAction = now
                val killed = killBackgroundApps()
                alertHot(temp, killed)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "निगरानी", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "गर्मी की चेतावनी", NotificationManager.IMPORTANCE_HIGH)
        )

        val n = build(CH_STATUS, "फ़ोन बूस्टर चालू", "तापमान की निगरानी हो रही है")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_STATUS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_STATUS, n)
        }

        registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try {
            unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun updateStatus(temp: Float, level: Int) {
        val text = "तापमान $temp°C  |  बैटरी $level%" + if (temp >= hotTemp) "  🔥" else "  ✅"
        getSystemService(NotificationManager::class.java)
            .notify(ID_STATUS, build(CH_STATUS, "फ़ोन बूस्टर चालू", text))
    }

    private fun alertHot(temp: Float, killed: Int) {
        val text = "फ़ोन $temp°C पर गर्म है। $killed बैकग्राउंड ऐप बंद किए। " +
            "चार्जर निकालो, कवर हटाओ और गेम/कैमरा बंद करो।"
        getSystemService(NotificationManager::class.java)
            .notify(ID_ALERT, build(CH_ALERT, "🔥 फ़ोन गर्म है", text))
    }

    private fun killBackgroundApps(): Int {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var count = 0
        for (app in packageManager.getInstalledApplications(0)) {
            if (app.packageName == packageName) continue
            try {
                am.killBackgroundProcesses(app.packageName)
                count++
            } catch (_: Exception) {
            }
        }
        return count
    }

    private fun build(channel: String, title: String, text: String): Notification =
        Notification.Builder(this, channel)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOnlyAlertOnce(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()

    companion object {
        private const val CH_STATUS = "status"
        private const val CH_ALERT = "alert"
        private const val ID_STATUS = 1
        private const val ID_ALERT = 2
    }
}
