package com.example.phonebooster

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED &&
            context.getSharedPreferences("pb", Context.MODE_PRIVATE).getBoolean("monitor", false)
        ) {
            context.startForegroundService(Intent(context, CoolService::class.java))
        }
    }
}
